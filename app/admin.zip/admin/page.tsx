// app/admin/page.tsx
"use client"

export default function AdminHome() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Welcome, Admin!</h1>
      <p>Select a section from the sidebar to manage bookings or services.</p>
    </div>
  )
}
