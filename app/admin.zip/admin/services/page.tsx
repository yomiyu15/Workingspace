// app/admin/services/page.tsx
"use client"

import { useEffect, useState } from "react"

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api"

export default function AdminServices() {
  const [services, setServices] = useState<any[]>([])

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const res = await fetch(`${API_BASE}/services`) // add auth if needed
        const data = await res.json()
        setServices(data)
      } catch (err) {
        console.error(err)
      }
    }
    fetchServices()
  }, [])

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Services</h1>
      {services.length === 0 ? (
        <p>No services yet.</p>
      ) : (
        <ul className="space-y-4">
          {services.map((s) => (
            <li key={s.id} className="border p-4 rounded">
              <p>
                <strong>{s.name}</strong> - Br {s.price}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
